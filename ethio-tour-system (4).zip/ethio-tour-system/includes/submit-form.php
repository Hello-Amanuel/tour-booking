<?php
/**
 * ETS Frontend Tour Submission v5.0
 * Shortcode: [ets_submit_tour]
 *
 * Step Structure:
 *   1. Basics       — Title, Description, Category (product_cat), Tour Type (tour_type), Badge
 *   2. Tour Details — Duration, Transport (multi), Group Size, Start/End, Location (multi), Language (multi), WhatsApp
 *   3. Itinerary    — Itinerary Builder + Good to Know
 *   4. Price        — Price Type, Per Person, Sale, Highlights, Includes, Excludes, Booking Options, Cancellation
 *   5. Images       — Gallery upload (up to 8)
 *   6. Review       — Summary + Submit
 */
defined( 'ABSPATH' ) || exit;


/*═══════════════════════════════════════
  ENQUEUE FORM ASSETS
═══════════════════════════════════════*/
add_action( 'wp_enqueue_scripts', function () {
    if ( is_admin() ) return;

    global $post;
    $is_submit_page = is_a( $post, 'WP_Post' ) && has_shortcode( $post->post_content, 'ets_submit_tour' );
    if ( ! $is_submit_page ) return;

    wp_enqueue_style(  'ets-submit-css', ETS_URL . 'assets/css/ets-submit.css', [], ETS_VERSION );
    wp_enqueue_script( 'ets-submit-js',  ETS_URL . 'assets/js/ets-submit.js',  [], ETS_VERSION, true );

    wp_localize_script( 'ets-submit-js', 'ets_submit_vars', [
        'ajax_url'        => admin_url( 'admin-ajax.php' ),
        'nonce'           => wp_create_nonce( 'ets_submit_tour' ),
        'logged_in'       => is_user_logged_in() ? 'yes' : 'no',
        'currency_symbol' => get_woocommerce_currency_symbol(),
        'currency_pos'    => get_option( 'woocommerce_currency_pos', 'left' ),
    ] );
}, 5 );


/*═══════════════════════════════════════
  SHORTCODE
═══════════════════════════════════════*/
add_shortcode( 'ets_submit_tour', function () {
    ob_start();

    if ( ! is_user_logged_in() ) {
        echo '<div style="text-align:center;padding:60px 24px;font-family:sans-serif;">'
           . '<p style="font-size:1rem;color:#374151;margin-bottom:16px;">You must be logged in to submit a tour.</p>'
           . '<a href="' . esc_url( wp_login_url( get_permalink() ) ) . '" '
           . 'style="background:#1a6b4a;color:#fff;padding:12px 28px;border-radius:8px;font-weight:700;text-decoration:none;">Log In</a>'
           . '</div>';
        return ob_get_clean();
    }

    // Fetch taxonomies
    $product_cats   = get_terms( [ 'taxonomy' => 'product_cat',  'hide_empty' => false, 'orderby' => 'name' ] );
    $tour_types     = get_terms( [ 'taxonomy' => 'tour_type',    'hide_empty' => false ] );
    $tour_locations = get_terms( [ 'taxonomy' => 'tour_location','hide_empty' => false ] );
    $currency_sym   = get_woocommerce_currency_symbol();
    $currency_code  = get_woocommerce_currency();
    ?>

<div class="ets-submit-wrap">

    <!-- ── Hero ── -->
    <div class="ets-sf-hero">
        <div class="ets-sf-hero-inner">
            <span class="ets-sf-hero-eyebrow">Tour Partner Portal</span>
            <h1>List Your Tour</h1>
            <p>Share your unique Ethiopian experiences with travellers worldwide. Complete the form below to submit your tour for review.</p>
        </div>
    </div>

    <!-- ── 6-Step Progress Nav ── -->
    <div class="ets-sf-progress">
        <div class="ets-sf-progress-inner">
            <?php
            $steps = [ 'Basics', 'Tour Details', 'Itinerary', 'Price', 'Images', 'Review' ];
            foreach ( $steps as $i => $label ) : ?>
                <button type="button" class="ets-sf-step-tab <?php echo $i === 0 ? 'is-active' : ''; ?>" data-step="<?php echo $i; ?>">
                    <span class="ets-sf-step-num"><span class="ets-sf-step-numval"><?php echo $i + 1; ?></span></span>
                    <?php echo esc_html( $label ); ?>
                </button>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="ets-sf-main" id="ets-sf-form-wrap">
    <form id="ets-submit-form" novalidate>
        <?php wp_nonce_field( 'ets_submit_tour', 'ets_submit_nonce' ); ?>

        <!-- ══════════════════════════════════════
             STEP 1 — BASICS
             Title · Description · Category · Tour Type · Badge
        ══════════════════════════════════════ -->
        <div class="ets-sf-panel is-active" data-step="0">
            <h2 class="ets-sf-panel-title">Tour Basics</h2>
            <p class="ets-sf-panel-sub">The essential identity of your tour — title, description, category, and display settings.</p>
            <div class="ets-sf-notice ets-sf-notice--error"></div>

            <div class="ets-sf-card">
                <p class="ets-sf-card-title">Tour Identity</p>

                <div class="ets-sf-field">
                    <label class="ets-sf-label" for="ets-sf-title">Tour Title <span class="req">*</span></label>
                    <input type="text" id="ets-sf-title" class="ets-sf-input" required
                           placeholder="e.g. Addis Ababa Half Day City Tour"
                           data-maxlength="80">
                    <span class="ets-sf-charcount"></span>
                    <span class="ets-sf-error-msg">⚠ Please enter a tour title</span>
                </div>

                <div class="ets-sf-field">
                    <label class="ets-sf-label" for="ets-sf-description">Tour Description <span class="req">*</span></label>
                    <textarea id="ets-sf-description" class="ets-sf-textarea" required rows="5"
                              placeholder="Write a detailed and compelling description of your tour experience. This is shown on the tour page."
                              data-maxlength="1500"></textarea>
                    <span class="ets-sf-charcount"></span>
                    <span class="ets-sf-error-msg">⚠ Please enter a tour description</span>
                </div>
            </div>

            <div class="ets-sf-card">
                <p class="ets-sf-card-title">Category &amp; Type</p>

                <div class="ets-sf-grid-2">
                    <div class="ets-sf-field">
                        <label class="ets-sf-label" for="ets-sf-product-cat">Tour Category <span class="req">*</span></label>
                        <select id="ets-sf-product-cat" class="ets-sf-select" required>
                            <option value="">— Select category —</option>
                            <?php if ( ! is_wp_error( $product_cats ) ) foreach ( $product_cats as $cat ) :
                                if ( $cat->slug === 'uncategorized' ) continue; ?>
                                <option value="<?php echo esc_attr( $cat->term_id ); ?>"><?php echo esc_html( $cat->name ); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <span class="ets-sf-hint">e.g. Cultural, Adventure, Day Trip</span>
                        <span class="ets-sf-error-msg">⚠ Please select a category</span>
                    </div>
                    <div class="ets-sf-field">
                        <label class="ets-sf-label" for="ets-sf-tour-type">Tour Type</label>
                        <select id="ets-sf-tour-type" class="ets-sf-select">
                            <option value="">— Select type —</option>
                            <?php if ( ! is_wp_error( $tour_types ) ) foreach ( $tour_types as $t ) : ?>
                                <option value="<?php echo esc_attr( $t->term_id ); ?>"><?php echo esc_html( $t->name ); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <span class="ets-sf-hint">e.g. Private, Group, Self-Guided</span>
                    </div>
                </div>

                <div class="ets-sf-field">
                    <label class="ets-sf-label" for="ets-sf-badge">Highlight Badge <small style="font-weight:400;color:#6b7280;">Optional</small></label>
                    <select id="ets-sf-badge" class="ets-sf-select">
                        <option value="">— None —</option>
                        <option value="bestseller">Best Seller</option>
                        <option value="likely_to_sell">Likely to Sell Out</option>
                        <option value="new">New</option>
                        <option value="exclusive">Exclusive</option>
                    </select>
                    <span class="ets-sf-hint">Shown as a badge on your tour card and listing page</span>
                </div>
            </div>

            <div class="ets-sf-nav">
                <button type="button" class="ets-sf-btn ets-sf-btn-prev" style="visibility:hidden;">← Back</button>
                <button type="button" class="ets-sf-btn ets-sf-btn-next">Continue → Tour Details</button>
            </div>
        </div>


        <!-- ══════════════════════════════════════
             STEP 2 — TOUR DETAILS
             Duration · Transport · Group Size · Start/End · Location (multi) · Language (multi) · WhatsApp
        ══════════════════════════════════════ -->
        <div class="ets-sf-panel" data-step="1">
            <h2 class="ets-sf-panel-title">Tour Details</h2>
            <p class="ets-sf-panel-sub">Practical information travellers need to plan and book their trip.</p>
            <div class="ets-sf-notice ets-sf-notice--error"></div>

            <div class="ets-sf-card">
                <p class="ets-sf-card-title">Logistics</p>

                <div class="ets-sf-grid-2">
                    <div class="ets-sf-field">
                        <label class="ets-sf-label" for="ets-sf-duration">Duration <span class="req">*</span></label>
                        <input type="text" id="ets-sf-duration" class="ets-sf-input" required
                               placeholder="e.g. Half Day / 3 Days">
                        <span class="ets-sf-error-msg">⚠ Duration is required</span>
                    </div>
                    <div class="ets-sf-field">
                        <label class="ets-sf-label" for="ets-sf-group-size">Group Size</label>
                        <input type="text" id="ets-sf-group-size" class="ets-sf-input"
                               placeholder="e.g. 2–12 People">
                    </div>
                </div>

                <div class="ets-sf-field">
                    <label class="ets-sf-label" for="ets-sf-transport-select">Mode of Transportation</label>
                    <select id="ets-sf-transport-select" class="ets-sf-select ets-ms-select" data-target="transport">
                        <option value="">— Select transport mode —</option>
                        <?php foreach ( ets_transport_modes() as $mode ) : ?>
                            <option value="<?php echo esc_attr( $mode ); ?>"><?php echo esc_html( $mode ); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="ets-ms-tags" id="ets-ms-tags-transport"></div>
                    <input type="hidden" id="ets-sf-transport" name="ets_transport">
                    <span class="ets-sf-hint">Select one at a time — chosen items appear below as tags</span>
                </div>

                <div class="ets-sf-grid-2">
                    <div class="ets-sf-field">
                        <label class="ets-sf-label" for="ets-sf-start-point">Start Point <span class="req">*</span></label>
                        <input type="text" id="ets-sf-start-point" class="ets-sf-input" required
                               placeholder="e.g. Hotel Lobby / Bole Airport">
                        <span class="ets-sf-error-msg">⚠ Start point is required</span>
                    </div>
                    <div class="ets-sf-field">
                        <label class="ets-sf-label" for="ets-sf-end-point">End Point</label>
                        <input type="text" id="ets-sf-end-point" class="ets-sf-input"
                               placeholder="e.g. Same as start point">
                    </div>
                </div>
            </div>

            <div class="ets-sf-card">
                <p class="ets-sf-card-title">Location &amp; Language</p>

                <div class="ets-sf-field">
                    <label class="ets-sf-label" for="ets-sf-location-select">Location <span class="req">*</span></label>
                    <select id="ets-sf-location-select" class="ets-sf-select ets-ms-select" data-target="tour_location" data-required="1">
                        <option value="">— Select a location —</option>
                        <?php if ( ! is_wp_error( $tour_locations ) ) foreach ( $tour_locations as $l ) : ?>
                            <option value="<?php echo esc_attr( $l->term_id ); ?>"><?php echo esc_html( $l->name ); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="ets-ms-tags" id="ets-ms-tags-tour_location"></div>
                    <input type="hidden" id="ets-sf-tour-location" name="ets_tour_location">
                    <span class="ets-sf-hint">Select one at a time — chosen locations appear below as tags</span>
                    <span class="ets-sf-error-msg">⚠ Please select at least one location</span>
                </div>

                <div class="ets-sf-field">
                    <label class="ets-sf-label" for="ets-sf-languages-select">Languages Offered</label>
                    <select id="ets-sf-languages-select" class="ets-sf-select ets-ms-select" data-target="languages">
                        <option value="">— Select a language —</option>
                        <?php foreach ( ets_languages_list() as $lang ) : ?>
                            <option value="<?php echo esc_attr( $lang ); ?>"><?php echo esc_html( $lang ); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="ets-ms-tags" id="ets-ms-tags-languages"></div>
                    <input type="hidden" id="ets-sf-languages" name="ets_languages">
                    <span class="ets-sf-hint">Select one at a time — chosen languages appear below as tags</span>
                </div>

                <div class="ets-sf-field">
                    <label class="ets-sf-label" for="ets-sf-whatsapp">WhatsApp Number</label>
                    <input type="text" id="ets-sf-whatsapp" class="ets-sf-input"
                           placeholder="e.g. +251911000000">
                    <span class="ets-sf-hint">Include country code — shown as a "Chat on WhatsApp" button on the tour page</span>
                </div>
            </div>

            <div class="ets-sf-nav">
                <button type="button" class="ets-sf-btn ets-sf-btn-prev">← Back</button>
                <button type="button" class="ets-sf-btn ets-sf-btn-next">Continue → Itinerary</button>
            </div>
        </div>


        <!-- ══════════════════════════════════════
             STEP 3 — ITINERARY + GOOD TO KNOW
        ══════════════════════════════════════ -->
        <div class="ets-sf-panel" data-step="2">
            <h2 class="ets-sf-panel-title">Itinerary</h2>
            <p class="ets-sf-panel-sub">Describe each day or stop — a detailed itinerary significantly increases bookings.</p>
            <div class="ets-sf-notice ets-sf-notice--error"></div>

            <div class="ets-sf-card">
                <p class="ets-sf-card-title">Day-by-Day Plan</p>
                <div id="ets-sf-itin-list" class="ets-sf-dyn-list"></div>
                <p id="ets-sf-itin-empty" style="color:#9ca3af;font-size:.875rem;text-align:center;padding:16px 0;margin:0;">
                    No itinerary items yet — click below to add your first day or stop.
                </p>
                <button type="button" class="ets-sf-add-row-btn" id="ets-sf-add-itin">+ Add Day / Stop</button>
            </div>

            <div class="ets-sf-card">
                <p class="ets-sf-card-title">Good to Know</p>
                <div class="ets-sf-field">
                    <label class="ets-sf-label" for="ets-sf-know-before">Important Tips &amp; Information</label>
                    <textarea id="ets-sf-know-before" class="ets-sf-textarea" rows="5"
                              placeholder="Wear comfortable walking shoes&#10;Bring sunscreen&#10;Modest dress required at religious sites&#10;Photography may be restricted in some areas"></textarea>
                    <span class="ets-sf-hint">One tip per line — shown in the "Good to Know" section on the tour page</span>
                </div>
            </div>

            <div class="ets-sf-nav">
                <button type="button" class="ets-sf-btn ets-sf-btn-prev">← Back</button>
                <button type="button" class="ets-sf-btn ets-sf-btn-next">Continue → Price</button>
            </div>
        </div>


        <!-- ══════════════════════════════════════
             STEP 4 — PRICE & INCLUSIONS
             Price Type · Per Person · Sale · Highlights · Includes · Excludes · Booking Options · Cancellation
        ══════════════════════════════════════ -->
        <div class="ets-sf-panel" data-step="3">
            <h2 class="ets-sf-panel-title">Pricing &amp; Inclusions</h2>
            <p class="ets-sf-panel-sub">Set your pricing, tour highlights, what's included, and your booking policies.</p>
            <div class="ets-sf-notice ets-sf-notice--error"></div>

            <!-- Pricing -->
            <div class="ets-sf-card">
                <p class="ets-sf-card-title">Pricing</p>

                <div class="ets-sf-field" style="margin-bottom:20px;">
                    <label class="ets-sf-label">Price Type <span class="req">*</span></label>
                    <div class="ets-sf-radio-group" id="ets-sf-price-type-group">
                        <label class="ets-sf-radio-option">
                            <input type="radio" name="ets_price_type" id="ets-pt-fixed" value="per_person" checked>
                            <span class="ets-sf-radio-box"></span>
                            <div>
                                <span class="ets-sf-radio-label">Fixed Price Per Person</span>
                                <span class="ets-sf-radio-desc">Standard per-person pricing displayed on the tour</span>
                            </div>
                        </label>
                        <label class="ets-sf-radio-option" style="margin-top:10px;">
                            <input type="radio" name="ets_price_type" id="ets-pt-request" value="on_request">
                            <span class="ets-sf-radio-box"></span>
                            <div>
                                <span class="ets-sf-radio-label">Price on Request</span>
                                <span class="ets-sf-radio-desc">Display "Contact us" — suitable for custom/group tours</span>
                            </div>
                        </label>
                    </div>
                </div>

                <div id="ets-sf-price-fields">
                    <div class="ets-sf-grid-2">
                        <div class="ets-sf-field">
                            <label class="ets-sf-label" for="ets-sf-price">
                                Price (<?php echo esc_html( $currency_code ); ?> per person) <span class="req">*</span>
                            </label>
                            <div class="ets-sf-price-wrap">
                                <span class="ets-sf-currency"><?php echo esc_html( $currency_sym ); ?></span>
                                <input type="number" id="ets-sf-price" class="ets-sf-input" required
                                       min="0" step="0.01" placeholder="0.00">
                            </div>
                            <span class="ets-sf-error-msg">⚠ Please enter a price</span>
                        </div>
                        <div class="ets-sf-field">
                            <label class="ets-sf-label" for="ets-sf-sale-price">
                                Sale Price (<?php echo esc_html( $currency_sym ); ?>) <small style="font-weight:400;color:#6b7280;">Optional</small>
                            </label>
                            <div class="ets-sf-price-wrap">
                                <span class="ets-sf-currency"><?php echo esc_html( $currency_sym ); ?></span>
                                <input type="number" id="ets-sf-sale-price" class="ets-sf-input"
                                       min="0" step="0.01" placeholder="Leave blank if no sale">
                            </div>
                            <span class="ets-sf-hint">Must be lower than the regular price</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tour Highlights -->
<!--             <div class="ets-sf-card">
                <p class="ets-sf-card-title">Tour Highlights</p>
                <div class="ets-sf-field">
                    <label class="ets-sf-label" for="ets-sf-highlights">Highlights <span class="req">*</span></label>
                    <textarea id="ets-sf-highlights" class="ets-sf-textarea" rows="5" required
                              placeholder="Visit St George Cathedral&#10;Explore the Mercato Market&#10;Traditional coffee ceremony&#10;Panoramic views from Entoto Hill"></textarea>
                    <span class="ets-sf-hint">One highlight per line — shown as bullet points on the tour page</span>
                    <span class="ets-sf-error-msg">⚠ Please add at least one highlight</span>
                </div>
            </div>
 -->
            <!-- Includes / Excludes -->
            <div class="ets-sf-card">
                <p class="ets-sf-card-title">Includes &amp; Excludes</p>
                <div class="ets-sf-grid-2">
                    <div class="ets-sf-field">
                        <label class="ets-sf-label" for="ets-sf-includes">✓ What's Included</label>
                        <textarea id="ets-sf-includes" class="ets-sf-textarea" rows="6"
                                  placeholder="Hotel pickup&#10;Licensed English guide&#10;All entrance fees&#10;Bottled water&#10;Air-conditioned transport"></textarea>
                        <span class="ets-sf-hint">One item per line</span>
                    </div>
                    <div class="ets-sf-field">
                        <label class="ets-sf-label" for="ets-sf-excludes">✕ Not Included</label>
                        <textarea id="ets-sf-excludes" class="ets-sf-textarea" rows="6"
                                  placeholder="Meals &amp; drinks&#10;Tips for guide&#10;Personal expenses&#10;Travel insurance"></textarea>
                        <span class="ets-sf-hint">One item per line</span>
                    </div>
                </div>
            </div>

            <!-- Booking Options -->
            <div class="ets-sf-card">
                <p class="ets-sf-card-title">Booking Options</p>

                <div class="ets-sf-field" style="margin-bottom:16px;">
                    <label class="ets-sf-label">Options</label>
                    <div class="ets-sf-toggles">
                        <label class="ets-sf-toggle">
                            <input type="checkbox" id="ets-sf-free-cancel">
                            <span class="ets-sf-toggle-box">✓</span>
                            <span class="ets-sf-toggle-label">✓ Free Cancellation</span>
                        </label>
                        <label class="ets-sf-toggle">
                            <input type="checkbox" id="ets-sf-instant-confirm">
                            <span class="ets-sf-toggle-box">✓</span>
                            <span class="ets-sf-toggle-label">⚡ Instant Confirmation</span>
                        </label>
                    </div>
                </div>

                <div class="ets-sf-field">
                    <label class="ets-sf-label" for="ets-sf-cancellation">Cancellation Policy</label>
                    <select id="ets-sf-cancellation" class="ets-sf-select">
                        <?php foreach ( ets_cancellation_options() as $val => $label ) : ?>
                            <option value="<?php echo esc_attr( $val ); ?>"><?php echo esc_html( $label ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="ets-sf-nav">
                <button type="button" class="ets-sf-btn ets-sf-btn-prev">← Back</button>
                <button type="button" class="ets-sf-btn ets-sf-btn-next">Continue → Images</button>
            </div>
        </div>


        <!-- ══════════════════════════════════════
             STEP 5 — IMAGES / GALLERY
        ══════════════════════════════════════ -->
        <div class="ets-sf-panel" data-step="4">
            <h2 class="ets-sf-panel-title">Tour Photos</h2>
            <p class="ets-sf-panel-sub">Upload stunning photos. The first image becomes the cover. Up to 8 photos.</p>
            <div class="ets-sf-notice ets-sf-notice--error"></div>

            <div class="ets-sf-card">
                <p class="ets-sf-card-title">Upload Images</p>

                <div class="ets-sf-notice ets-sf-notice--error"></div>

                <div class="ets-sf-upload-zone" id="ets-sf-upload-zone">
                    <input type="file" id="ets-sf-file-input" accept="image/*" multiple>
                    <div class="ets-sf-upload-icon">📷</div>
                    <div class="ets-sf-upload-title">Drag &amp; drop photos here, or click to browse</div>
                    <div class="ets-sf-upload-sub">JPG, PNG, WebP — max 8 photos · First photo = cover image</div>
                </div>
                <div class="ets-sf-preview-grid" id="ets-sf-preview-grid"></div>

                <p style="margin:14px 0 0;font-size:.8rem;color:#dc2626;display:flex;align-items:center;gap:6px;">
                    <span>*</span> At least 1 photo is required to submit your tour.
                </p>
            </div>

            <div class="ets-sf-card" style="background:#f0f9ff;border-color:#bae6fd;">
                <p style="font-size:.875rem;color:#0c4a6e;margin:0;display:flex;align-items:flex-start;gap:10px;">
                    <span>💡</span>
                    <span><strong>Pro tip:</strong> Tours with 5–8 high-quality landscape photos receive significantly more bookings. Use real people and great lighting where possible.</span>
                </p>
            </div>

            <div class="ets-sf-nav">
                <button type="button" class="ets-sf-btn ets-sf-btn-prev">← Back</button>
                <button type="button" class="ets-sf-btn ets-sf-btn-next">Review Submission →</button>
            </div>
        </div>


        <!-- ══════════════════════════════════════
             STEP 6 — REVIEW & SUBMIT
        ══════════════════════════════════════ -->
        <div class="ets-sf-panel" data-step="5">
            <h2 class="ets-sf-panel-title">Review &amp; Submit</h2>
            <p class="ets-sf-panel-sub">Check your tour details before submitting. Our team will review and publish within 1–2 business days.</p>
            <div class="ets-sf-notice ets-sf-notice--error"></div>

            <div class="ets-sf-card">
                <p class="ets-sf-card-title">Summary</p>
                <div class="ets-sf-review-grid" id="ets-sf-review-grid"></div>
            </div>

            <div class="ets-sf-card" style="background:#fffbeb;border-color:#fde68a;">
                <p style="font-size:.875rem;color:#92400e;margin:0;display:flex;align-items:flex-start;gap:10px;">
                    <span>ℹ</span>
                    <span>Your tour will be submitted as a <strong>draft</strong> pending admin review. You'll receive an email once it's approved and live on the site.</span>
                </p>
            </div>

            <div class="ets-sf-nav">
                <button type="button" class="ets-sf-btn ets-sf-btn-prev">← Back</button>
                <button type="button" id="ets-sf-submit-btn" class="ets-sf-btn ets-sf-btn-submit">
                    <span class="ets-sf-btn-text">🚀 Submit Tour for Review</span>
                    <span class="ets-sf-spinner"></span>
                </button>
            </div>
        </div>

    </form>
    </div>

    <!-- ── Success Screen ── -->
    <div class="ets-sf-success" id="ets-sf-success">
        <div class="ets-sf-success-icon">✓</div>
        <h2>Tour Submitted!</h2>
        <p>Thank you! Our team will review your tour within 1–2 business days and notify you by email once it's approved and live.</p>
        <div class="ets-sf-success-actions">
            <a href="<?php echo esc_url( home_url() ); ?>"
               style="display:inline-flex;align-items:center;gap:8px;padding:13px 26px;border-radius:10px;background:#1a6b4a;color:#fff;font-family:sans-serif;font-weight:700;text-decoration:none;">
                ← Back to Home
            </a>
            <a href="#" id="ets-sf-success-link"
               style="display:none;align-items:center;gap:8px;padding:13px 26px;border-radius:10px;background:#fff;border:1.5px solid #e5e7eb;color:#111827;font-family:sans-serif;font-weight:700;text-decoration:none;">
                View Draft →
            </a>
        </div>
    </div>

</div>
    <?php
    return ob_get_clean();
} );


/*═══════════════════════════════════════
  AJAX HANDLER
═══════════════════════════════════════*/
add_action( 'wp_ajax_ets_submit_tour', 'ets_ajax_submit_tour' );

function ets_ajax_submit_tour() {

    if ( ! is_user_logged_in() ) wp_send_json_error( 'You must be logged in.' );
    check_ajax_referer( 'ets_submit_tour', 'ets_submit_nonce' );

    $raw  = isset( $_POST['data'] ) ? wp_unslash( $_POST['data'] ) : '{}';
    $data = json_decode( $raw, true );
    if ( ! is_array( $data ) ) wp_send_json_error( 'Invalid data.' );

    $s  = fn( $k ) => sanitize_text_field( $data[$k] ?? '' );
    $st = fn( $k ) => sanitize_textarea_field( $data[$k] ?? '' );

    // Validate required fields
    $title = $s( 'title' );
    if ( ! $title )                    wp_send_json_error( 'Tour title is required.' );
    if ( empty( $data['product_cat'] ) ) wp_send_json_error( 'Please select a tour category.' );
    if ( empty( $data['tour_location'] ) ) wp_send_json_error( 'Please select at least one location.' );

    // Create WooCommerce product
    $product = new WC_Product_Simple();
    $product->set_name( $title );
    $product->set_status( 'pending' );
    $product->set_catalog_visibility( 'visible' );
    $product->set_description( wp_kses_post( $data['description'] ?? '' ) );

    // Pricing
    $price_type = $s( 'price_type' );
    if ( $price_type !== 'on_request' ) {
        $price = (float) ( $data['price'] ?? 0 );
        if ( $price > 0 ) {
            $product->set_regular_price( $price );
            $sale = (float) ( $data['sale_price'] ?? 0 );
            if ( $sale > 0 && $sale < $price ) $product->set_sale_price( $sale );
        }
    }

    $post_id = $product->save();
    if ( ! $post_id || is_wp_error( $post_id ) ) wp_send_json_error( 'Could not create product.' );

    wp_update_post( [ 'ID' => $post_id, 'post_author' => get_current_user_id() ] );

    // Save post meta
    $metas = [
        '_tour_price_type'        => $price_type,
        '_tour_duration'          => $s( 'duration' ),
        '_tour_group_size'        => $s( 'group_size' ),
        '_tour_transport'         => $s( 'transport' ),
        '_tour_start_point'       => $s( 'start_point' ),
        '_tour_end_point'         => $s( 'end_point' ),
        '_tour_languages'         => $s( 'languages' ),
        '_tour_whatsapp'          => $s( 'whatsapp' ),
        '_tour_cancellation'      => $s( 'cancellation' ),
        '_tour_badge'             => $s( 'badge' ),
        '_tour_highlights'        => $st( 'highlights' ),
        '_tour_includes'          => $st( 'includes' ) ?: ETS_DEFAULT_INCLUDES,
        '_tour_excludes'          => $st( 'excludes' ) ?: ETS_DEFAULT_EXCLUDES,
        '_tour_know_before'       => $st( 'know_before' ),
        '_tour_free_cancellation' => ! empty( $data['free_cancellation'] ) ? 'yes' : 'no',
        '_tour_instant_confirm'   => ! empty( $data['instant_confirm'] )   ? 'yes' : 'no',
    ];
    foreach ( $metas as $k => $v ) update_post_meta( $post_id, $k, $v );

    // Itinerary
    if ( ! empty( $data['itinerary'] ) && is_array( $data['itinerary'] ) ) {
        $rows = [];
        foreach ( $data['itinerary'] as $r ) {
            $rows[] = [
                'label'         => sanitize_text_field( $r['label']         ?? '' ),
                'title'         => sanitize_text_field( $r['title']         ?? '' ),
                'description'   => wp_kses_post( $r['description']          ?? '' ),
                'accommodation' => sanitize_text_field( $r['accommodation'] ?? '' ),
                'meals'         => sanitize_text_field( $r['meals']         ?? '' ),
            ];
        }
        update_post_meta( $post_id, '_tour_itinerary', $rows );
    }

    // ── Taxonomies ─────────────────────────────────────────

    // Tour Category: product_cat (required)
    if ( ! empty( $data['product_cat'] ) ) {
        wp_set_object_terms( $post_id, (int) $data['product_cat'], 'product_cat' );
    }

    // Tour Type: tour_type (optional)
    if ( ! empty( $data['tour_type'] ) ) {
        wp_set_object_terms( $post_id, (int) $data['tour_type'], 'tour_type' );
    }

    // Location: multi-select — accepts array of term IDs
    if ( ! empty( $data['tour_location'] ) ) {
        $location_ids = is_array( $data['tour_location'] )
            ? array_map( 'intval', $data['tour_location'] )
            : [ (int) $data['tour_location'] ];
        wp_set_object_terms( $post_id, $location_ids, 'tour_location' );
    }

    // ── Image Upload ────────────────────────────────────────
    if ( ! empty( $_FILES['tour_images'] ) ) {
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $files   = $_FILES['tour_images'];
        $allowed = [ 'image/jpeg', 'image/png', 'image/webp', 'image/gif' ];
        $gallery = [];

        for ( $i = 0; $i < count( $files['name'] ); $i++ ) {
            if ( $files['error'][$i] !== UPLOAD_ERR_OK ) continue;
            if ( ! in_array( $files['type'][$i], $allowed, true ) ) continue;
            $single = [
                'name'     => $files['name'][$i],
                'type'     => $files['type'][$i],
                'tmp_name' => $files['tmp_name'][$i],
                'error'    => $files['error'][$i],
                'size'     => $files['size'][$i],
            ];
            $att_id = media_handle_sideload( $single, $post_id );
            if ( ! is_wp_error( $att_id ) ) $gallery[] = $att_id;
        }

        if ( $gallery ) {
            set_post_thumbnail( $post_id, $gallery[0] );
            if ( count( $gallery ) > 1 ) {
                update_post_meta( $post_id, '_product_image_gallery', implode( ',', array_slice( $gallery, 1 ) ) );
            }
        }
    }

    // ── Admin Notification ─────────────────────────────────
    wp_mail(
        get_option( 'admin_email' ),
        '🗺 New Tour Submission: ' . $title,
        'New tour submitted by ' . wp_get_current_user()->display_name . "\n\nReview here: " . get_edit_post_link( $post_id, 'raw' )
    );

    wp_send_json_success( [
        'post_id' => $post_id,
        'url'     => get_edit_post_link( $post_id, 'raw' ),
    ] );
}