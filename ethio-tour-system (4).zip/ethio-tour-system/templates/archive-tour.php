<?php
/**
 * Template: Tour Archive / Taxonomy Page
 *
 * Used for tour_type and tour_location taxonomy archives.
 * Loaded by includes/template-override.php.
 *
 * File: templates/archive-tour.php
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

$term        = get_queried_object();
$term_name   = $term ? $term->name        : 'Tours';
$term_desc   = $term ? term_description() : '';
$is_location = $term && $term->taxonomy === 'tour_location';
?>

<div class="ets-wrap ets-archive">

    <!-- Archive header -->
    <div class="ets-archive-header">
        <h1 class="ets-archive-title">
            <?php echo $is_location ? '📍 ' : '🗂 '; ?>
            <?php echo esc_html( $term_name ); ?>
        </h1>
        <?php if ( $term_desc ) : ?>
            <div class="ets-archive-desc"><?php echo wp_kses_post( $term_desc ); ?></div>
        <?php endif; ?>
    </div>

    <!-- Tour grid -->
    <?php if ( have_posts() ) : ?>
        <div class="ets-tour-grid">
            <?php while ( have_posts() ) : the_post(); ?>
                <?php ets_render_tour_card( get_the_ID() ); ?>
            <?php endwhile; ?>
        </div>

        <!-- Pagination -->
        <div class="ets-pagination">
            <?php
            the_posts_pagination( [
                'mid_size'  => 2,
                'prev_text' => '‹ Previous',
                'next_text' => 'Next ›',
            ] );
            ?>
        </div>

    <?php else : ?>
        <div class="ets-no-results">
            <p>No tours found in <strong><?php echo esc_html( $term_name ); ?></strong> yet. Check back soon!</p>
            <a href="<?php echo esc_url( get_post_type_archive_link( 'product' ) ); ?>" class="ets-card-btn">Browse all tours</a>
        </div>
    <?php endif; ?>

</div><!-- /ets-archive -->

<?php get_footer();