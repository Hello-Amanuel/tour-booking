/* Ethio Tour System v4.0 — Frontend JS */
(function () {
    'use strict';

    /* ════════════════════════════════
       VIATOR-STYLE GALLERY
       ════════════════════════════════ */
    var thumbStrip = document.getElementById('ets-thumbstrip');
    var mainPane   = document.getElementById('ets-gmain');

    if ( mainPane ) {
        var allFulls   = JSON.parse( mainPane.getAttribute('data-fulls') || '[]' );
        var current    = 0;
        var thumbEls   = thumbStrip ? Array.from( thumbStrip.querySelectorAll('.ets-gthumb') ) : [];

        function goToImage( idx ) {
            if ( idx < 0 ) idx = allFulls.length - 1;
            if ( idx >= allFulls.length ) idx = 0;
            current = idx;

            // Update main pane background
            mainPane.style.backgroundImage = "url('" + allFulls[current] + "')";

            // Update active thumb
            thumbEls.forEach(function (th, i) {
                th.classList.toggle('is-active', i === current);
            });
        }

        // Thumb click
        thumbEls.forEach(function (th, i) {
            th.addEventListener('click', function () { goToImage(i); });
        });

        // Prev / Next arrows
        var btnPrev = document.getElementById('ets-gnav-prev');
        var btnNext = document.getElementById('ets-gnav-next');
        if ( btnPrev ) btnPrev.addEventListener('click', function (e) { e.stopPropagation(); goToImage(current - 1); });
        if ( btnNext ) btnNext.addEventListener('click', function (e) { e.stopPropagation(); goToImage(current + 1); });

        // Touch swipe on main pane
        var touchStartX = 0;
        mainPane.addEventListener('touchstart', function (e) { touchStartX = e.touches[0].clientX; }, { passive: true });
        mainPane.addEventListener('touchend',   function (e) {
            var diff = touchStartX - e.changedTouches[0].clientX;
            if ( Math.abs(diff) > 40 ) goToImage( diff > 0 ? current + 1 : current - 1 );
        });

        // Click main pane → open lightbox
        mainPane.addEventListener('click', function (e) {
            if ( e.target.tagName === 'BUTTON' ) return;
            openLb(current);
        });
    }


    /* ════════════════════════════════
       LIGHTBOX
       ════════════════════════════════ */
    var lbOverlay = null;
    var lbImgEl   = null;
    var lbCountEl = null;
    var lbImages  = [];
    var lbCurrent = 0;

    // Collect all full-res images from gallery
    if ( mainPane ) {
        lbImages = JSON.parse( mainPane.getAttribute('data-fulls') || '[]' );
    }

    function buildLightbox() {
        if ( lbOverlay ) return;
        lbOverlay = document.createElement('div');
        lbOverlay.className = 'ets-lightbox';
        lbOverlay.innerHTML =
            '<img class="ets-lb-img" id="ets-lb-img" src="" alt="Tour photo">' +
            '<button class="ets-lb-close" id="ets-lb-close" aria-label="Close">×</button>' +
            '<button class="ets-lb-prev"  id="ets-lb-prev"  aria-label="Previous">‹</button>' +
            '<button class="ets-lb-next"  id="ets-lb-next"  aria-label="Next">›</button>' +
            '<div class="ets-lb-counter"  id="ets-lb-counter"></div>';
        document.body.appendChild(lbOverlay);
        lbImgEl   = document.getElementById('ets-lb-img');
        lbCountEl = document.getElementById('ets-lb-counter');

        document.getElementById('ets-lb-close').addEventListener('click', closeLb);
        lbOverlay.addEventListener('click', function (e) { if ( e.target === lbOverlay ) closeLb(); });
        document.getElementById('ets-lb-prev').addEventListener('click', function () { lbNavigate(-1); });
        document.getElementById('ets-lb-next').addEventListener('click', function () { lbNavigate(1); });

        document.addEventListener('keydown', function (e) {
            if ( !lbOverlay.classList.contains('is-open') ) return;
            if ( e.key === 'Escape' )     closeLb();
            if ( e.key === 'ArrowLeft' )  lbNavigate(-1);
            if ( e.key === 'ArrowRight' ) lbNavigate(1);
        });
    }

    function openLb( index ) {
        buildLightbox();
        lbCurrent   = index;
        lbImgEl.src = lbImages[lbCurrent];
        if ( lbCountEl ) lbCountEl.textContent = (lbCurrent + 1) + ' / ' + lbImages.length;
        lbOverlay.classList.add('is-open');
        document.body.style.overflow = 'hidden';
    }

    function closeLb() {
        if ( lbOverlay ) lbOverlay.classList.remove('is-open');
        document.body.style.overflow = '';
    }

    function lbNavigate( dir ) {
        lbCurrent = (lbCurrent + dir + lbImages.length) % lbImages.length;
        lbImgEl.src = lbImages[lbCurrent];
        if ( lbCountEl ) lbCountEl.textContent = (lbCurrent + 1) + ' / ' + lbImages.length;
        // Sync gallery thumb
        var thumbEls2 = document.querySelectorAll('.ets-gthumb');
        thumbEls2.forEach(function (th, i) { th.classList.toggle('is-active', i === lbCurrent); });
    }

    // "See all photos" button
    var expandBtn = document.getElementById('ets-open-gallery');
    if ( expandBtn ) {
        expandBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            openLb(0);
        });
    }


    /* ════════════════════════════════
       TRAVELER QUANTITY + DYNAMIC PRICE
       ════════════════════════════════ */
    var qtyInput    = document.getElementById('ets-qty-input');
    var qtyMinus    = document.getElementById('ets-qty-minus');
    var qtyPlus     = document.getElementById('ets-qty-plus');
    var totalPriceEl = document.getElementById('ets-total-price');
    var basePriceEl  = document.getElementById('ets-base-price');
    var currSymEl    = document.getElementById('ets-currency-symbol');

    if ( qtyInput && basePriceEl ) {
        var basePrice    = parseFloat( basePriceEl.value ) || 0;
        var currSymbol   = currSymEl ? currSymEl.value : '£';

        function updateTotal() {
            var qty = parseInt( qtyInput.value ) || 1;
            if ( totalPriceEl ) {
                totalPriceEl.textContent = currSymbol + (basePrice * qty).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            }

            // Also sync WC quantity field (hidden)
            var wcQty = document.querySelector('.ets-booking-body input[name="quantity"]');
            if ( wcQty ) wcQty.value = qty;
        }

        if ( qtyMinus ) {
            qtyMinus.addEventListener('click', function () {
                var v = parseInt(qtyInput.value) || 1;
                if ( v > 1 ) { qtyInput.value = v - 1; updateTotal(); }
            });
        }
        if ( qtyPlus ) {
            qtyPlus.addEventListener('click', function () {
                var v = parseInt(qtyInput.value) || 1;
                if ( v < 99 ) { qtyInput.value = v + 1; updateTotal(); }
            });
        }

        updateTotal();
    }


    /* ════════════════════════════════
       ITINERARY READ MORE / LESS TOGGLE
       ════════════════════════════════ */
    var itinToggle = document.getElementById('ets-itin-toggle');
    if ( itinToggle ) {
        var itinWrap    = document.getElementById('ets-itin-wrap');
        var hiddenRows  = itinWrap ? Array.from( itinWrap.querySelectorAll('.ets-itin-hidden') ) : [];
        var expanded    = false;

        itinToggle.addEventListener('click', function () {
            expanded = !expanded;
            hiddenRows.forEach(function (row) {
                if ( expanded ) {
                    row.style.display = 'grid';
                } else {
                    row.style.display = 'none';
                }
            });

            var labelEl = itinToggle.querySelector('.ets-itin-toggle-label');
            if ( labelEl ) labelEl.textContent = expanded ? 'Read Less' : 'Read More';
            itinToggle.classList.toggle('is-expanded', expanded);
        });
    }

})();
