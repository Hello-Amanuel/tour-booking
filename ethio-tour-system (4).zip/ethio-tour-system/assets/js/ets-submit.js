/* ═══════════════════════════════════════════════════════════
   ETS Frontend Tour Submission — ets-submit.js v5.2 FINAL
   Fixes:
     1. Images ONLY validated on step 4 — never blocks step 1/2
     2. Dropdown + tag multi-select for transport/location/languages
     3. localStorage autosave — persists across page refresh
   ═══════════════════════════════════════════════════════════ */
(function () {
  'use strict';

  var form = document.getElementById('ets-submit-form');
  if (!form) return;

  var SAVE_KEY = 'ets_draft_v52';

  /* ─── State ─── */
  var currentStep = 0;
  var panels      = Array.from(document.querySelectorAll('.ets-sf-panel'));
  var tabs        = Array.from(document.querySelectorAll('.ets-sf-step-tab'));
  var itinCount   = 0;
  var imageFiles  = [];
  var msState     = { transport: [], tour_location: [], languages: [] };

  /* ═══════════════════════════════════════
     STEP NAVIGATION
  ═══════════════════════════════════════*/
  function goToStep(n) {
    if (n < 0 || n >= panels.length) return;
    if (n > currentStep) tabs[currentStep].classList.add('is-done');
    panels[currentStep].classList.remove('is-active');
    tabs[currentStep].classList.remove('is-active');
    currentStep = n;
    panels[currentStep].classList.add('is-active');
    tabs[currentStep].classList.add('is-active');
    tabs[currentStep].classList.remove('is-done');
    var prog = document.querySelector('.ets-sf-progress');
    if (prog) prog.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    window.scrollTo({ top: 0, behavior: 'smooth' });
    updateNavButtons();
    if (n === panels.length - 1) buildReview();
    saveProgress();
  }

  function updateNavButtons() {
    panels.forEach(function (panel) {
      var prev = panel.querySelector('.ets-sf-btn-prev');
      if (prev) prev.style.visibility = currentStep === 0 ? 'hidden' : 'visible';
    });
  }

  document.querySelectorAll('.ets-sf-btn-next').forEach(function (btn) {
    btn.addEventListener('click', function () {
      if (validateStep(currentStep)) goToStep(currentStep + 1);
    });
  });
  document.querySelectorAll('.ets-sf-btn-prev').forEach(function (btn) {
    btn.addEventListener('click', function () { goToStep(currentStep - 1); });
  });
  tabs.forEach(function (tab, i) {
    tab.addEventListener('click', function () {
      if (i < currentStep || tab.classList.contains('is-done')) goToStep(i);
    });
  });

  /* ═══════════════════════════════════════
     VALIDATION
     0 = Basics       : title, description, product_cat
     1 = Tour Details : duration, start_point, location (≥1 tag)
     2 = Itinerary    : nothing required
     3 = Price        : price (if fixed), highlights
     4 = Images       : ≥1 image  ← ONLY place images are checked
     5 = Review       : nothing
  ═══════════════════════════════════════*/
  function validateStep(idx) {
    var panel = panels[idx];
    clearErrors(panel);
    var valid = true;

    /* ── Step 4 only: image check ── */
    if (idx === 4) {
      if (imageFiles.length === 0) {
        var zone = document.getElementById('ets-sf-upload-zone');
        if (zone) { zone.classList.add('has-error'); setTimeout(function(){ zone.classList.remove('has-error'); }, 2500); }
        showNotice('Please upload at least one photo before continuing.', panel);
        return false;
      }
      return true;
    }

    /* ── All other steps: scan [required] but SKIP file inputs ── */
    panel.querySelectorAll('[required]').forEach(function (el) {
      if (el.tagName === 'INPUT' && el.type === 'file') return;  /* never check file inputs */
      var wrap = el.closest('.ets-sf-field');
      if (!el.value.trim()) {
        el.classList.add('has-error');
        if (wrap) wrap.classList.add('has-error');
        valid = false;
      }
    });

    /* ── Step 1 extra: location tags must have ≥1 ── */
    if (idx === 1 && msState.tour_location.length === 0) {
      var wrap = document.getElementById('ets-ms-tags-tour_location');
      if (wrap) wrap.closest('.ets-sf-field').classList.add('has-error');
      valid = false;
    }

    /* ── Step 3 extra: price only required when fixed ── */
    if (idx === 3) {
      var fixed = document.querySelector('input[name="ets_price_type"][value="per_person"]:checked');
      var priceEl = document.getElementById('ets-sf-price');
      if (priceEl) {
        if (fixed && (!priceEl.value || parseFloat(priceEl.value) <= 0)) {
          priceEl.classList.add('has-error');
          priceEl.closest('.ets-sf-field').classList.add('has-error');
          valid = false;
        } else {
          priceEl.classList.remove('has-error');
          if (priceEl.closest('.ets-sf-field')) priceEl.closest('.ets-sf-field').classList.remove('has-error');
        }
      }
    }

    if (!valid) showNotice('Please fill in all required fields before continuing.', panel);
    return valid;
  }

  function clearErrors(panel) {
    panel.querySelectorAll('.has-error').forEach(function(el){ el.classList.remove('has-error'); });
    panel.querySelectorAll('.ets-sf-notice').forEach(function(n){ n.classList.remove('is-visible'); n.textContent=''; });
  }

  function showNotice(msg, panel) {
    var n = panel.querySelector('.ets-sf-notice');
    if (!n) return;
    n.textContent = msg;
    n.className = 'ets-sf-notice is-visible ets-sf-notice--error';
    n.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    setTimeout(function(){ n.classList.remove('is-visible'); }, 5000);
  }

  form.addEventListener('input', function(e) {
    var f = e.target, wrap = f.closest('.ets-sf-field');
    if (f.value.trim()) { f.classList.remove('has-error'); if (wrap) wrap.classList.remove('has-error'); }
    saveProgress();
  });

  /* ═══════════════════════════════════════
     MULTI-SELECT DROPDOWNS + TAGS
     HTML: <select class="ets-ms-select" data-target="FIELD">
           <div class="ets-ms-tags" id="ets-ms-tags-FIELD">
           <input type="hidden" id="ets-sf-FIELD_ID">
  ═══════════════════════════════════════*/
  /* Map field name → hidden input id */
  var hiddenIds = {
    transport    : 'ets-sf-transport',
    tour_location: 'ets-sf-tour-location',
    languages    : 'ets-sf-languages'
  };

  function initMultiSelects() {
    document.querySelectorAll('.ets-ms-select').forEach(function(sel) {
      sel.addEventListener('change', function() {
        var target = sel.dataset.target;
        var val    = sel.value;
        var label  = sel.options[sel.selectedIndex] ? sel.options[sel.selectedIndex].text : val;
        sel.value  = '';   /* reset dropdown immediately */
        if (!val) return;
        if (!msState[target]) msState[target] = [];
        if (msState[target].indexOf(val) !== -1) return;  /* no duplicates */
        msState[target].push(val);
        renderTags(target, sel);
        /* clear location error once something picked */
        var field = sel.closest('.ets-sf-field');
        if (field) field.classList.remove('has-error');
        saveProgress();
      });
    });
  }

  function renderTags(target, selEl) {
    var tagsEl  = document.getElementById('ets-ms-tags-' + target);
    var hiddenEl = document.getElementById(hiddenIds[target]);
    if (!tagsEl) return;

    tagsEl.innerHTML = '';
    var vals = msState[target] || [];

    vals.forEach(function(val) {
      /* look up human label from the select options */
      var label = val;
      if (selEl) {
        for (var i = 0; i < selEl.options.length; i++) {
          if (selEl.options[i].value === val) { label = selEl.options[i].text; break; }
        }
      }
      var tag = document.createElement('span');
      tag.className = 'ets-ms-tag';
      tag.innerHTML = esc(label) + '<button type="button" class="ets-ms-tag-x" aria-label="Remove">&times;</button>';
      tag.querySelector('.ets-ms-tag-x').addEventListener('click', function() {
        var i = msState[target].indexOf(val);
        if (i > -1) msState[target].splice(i, 1);
        renderTags(target, selEl);
        saveProgress();
      });
      tagsEl.appendChild(tag);
    });

    if (hiddenEl) hiddenEl.value = vals.join(',');
  }

  /* ═══════════════════════════════════════
     PRICE TYPE TOGGLE
  ═══════════════════════════════════════*/
  var priceWrap = document.getElementById('ets-sf-price-fields');
  function syncPriceVisibility() {
    if (!priceWrap) return;
    var fixed = document.querySelector('input[name="ets_price_type"][value="per_person"]:checked');
    priceWrap.classList.toggle('is-hidden', !fixed);
    var priceEl = document.getElementById('ets-sf-price');
    if (priceEl) {
      if (fixed) priceEl.setAttribute('required','required');
      else priceEl.removeAttribute('required');
    }
  }
  document.querySelectorAll('input[name="ets_price_type"]').forEach(function(r) {
    r.addEventListener('change', function(){ syncPriceVisibility(); saveProgress(); });
  });
  syncPriceVisibility();

  /* ═══════════════════════════════════════
     IMAGE UPLOAD  (validation ONLY in step 4)
  ═══════════════════════════════════════*/
  var fileInput   = document.getElementById('ets-sf-file-input');
  var previewGrid = document.getElementById('ets-sf-preview-grid');
  var uploadZone  = document.getElementById('ets-sf-upload-zone');

  function renderPreviews() {
    if (!previewGrid) return;
    previewGrid.innerHTML = '';
    if (uploadZone) uploadZone.classList.remove('has-error');
    imageFiles.forEach(function(file, idx) {
      var reader = new FileReader();
      reader.onload = function(e) {
        var item = document.createElement('div');
        item.className = 'ets-sf-preview-item';
        item.innerHTML = '<img src="' + e.target.result + '" alt="">'
          + '<button type="button" class="ets-sf-preview-remove" data-idx="' + idx + '">&times;</button>';
        previewGrid.appendChild(item);
      };
      reader.readAsDataURL(file);
    });
    var sub = uploadZone && uploadZone.querySelector('.ets-sf-upload-sub');
    if (sub) sub.textContent = imageFiles.length
      ? imageFiles.length + ' photo' + (imageFiles.length > 1 ? 's' : '') + ' selected' + (imageFiles.length < 8 ? ' — add more' : ' — max reached')
      : 'JPG, PNG, WebP — max 8 photos · First photo = cover image';
  }

  if (fileInput) fileInput.addEventListener('change', function() {
    Array.from(this.files).forEach(function(f) {
      if (f.type.startsWith('image/') && imageFiles.length < 8) imageFiles.push(f);
    });
    renderPreviews(); this.value = '';
  });
  if (previewGrid) previewGrid.addEventListener('click', function(e) {
    var btn = e.target.closest('.ets-sf-preview-remove');
    if (btn) { imageFiles.splice(parseInt(btn.dataset.idx,10),1); renderPreviews(); }
  });
  if (uploadZone) {
    uploadZone.addEventListener('dragover',  function(e){ e.preventDefault(); this.classList.add('is-drag'); });
    uploadZone.addEventListener('dragleave', function(){  this.classList.remove('is-drag'); });
    uploadZone.addEventListener('drop', function(e) {
      e.preventDefault(); this.classList.remove('is-drag');
      Array.from(e.dataTransfer.files).forEach(function(f) {
        if (f.type.startsWith('image/') && imageFiles.length < 8) imageFiles.push(f);
      });
      renderPreviews();
    });
  }

  /* ═══════════════════════════════════════
     ITINERARY BUILDER
  ═══════════════════════════════════════*/
  var itinList  = document.getElementById('ets-sf-itin-list');
  var itinEmpty = document.getElementById('ets-sf-itin-empty');

  function addItinRow(data) {
    data = data || {};
    itinCount++;
    if (itinEmpty) itinEmpty.style.display = 'none';
    var row = document.createElement('div');
    row.className = 'ets-sf-dyn-row';
    row.innerHTML =
      '<div class="ets-sf-dyn-row-header">'
        +'<div class="ets-sf-dyn-handle"><div class="ets-sf-dyn-num">'+itinCount+'</div>'
        +'<input type="text" class="ets-sf-input ets-itin-label" placeholder="Day 1 / Stop 1" value="'+esc(data.label||'')+'" style="max-width:140px;margin:0;"></div>'
        +'<button type="button" class="ets-sf-remove-row">✕ Remove</button></div>'
      +'<div class="ets-sf-field" style="margin-bottom:10px;">'
        +'<label class="ets-sf-label">Title</label>'
        +'<input type="text" class="ets-sf-input ets-itin-title" placeholder="e.g. Addis Ababa City Tour" value="'+esc(data.title||'')+'"></div>'
      +'<div class="ets-sf-field" style="margin-bottom:10px;">'
        +'<label class="ets-sf-label">Description</label>'
        +'<textarea class="ets-sf-textarea ets-itin-desc" rows="2" placeholder="What happens on this day/stop...">'+esc(data.description||'')+'</textarea></div>'
      +'<div class="ets-sf-grid-2">'
        +'<div class="ets-sf-field" style="margin:0;"><label class="ets-sf-label">🏨 Accommodation</label>'
        +'<input type="text" class="ets-sf-input ets-itin-accommodation" placeholder="e.g. Hilton Hotel" value="'+esc(data.accommodation||'')+'"></div>'
        +'<div class="ets-sf-field" style="margin:0;"><label class="ets-sf-label">🍽 Meals Included</label>'
        +'<input type="text" class="ets-sf-input ets-itin-meals" placeholder="e.g. Breakfast & Dinner" value="'+esc(data.meals||'')+'"></div></div>';
    row.querySelector('.ets-sf-remove-row').addEventListener('click', function() {
      row.remove(); renumberRows();
      if (itinList && !itinList.querySelector('.ets-sf-dyn-row') && itinEmpty) itinEmpty.style.display='';
      saveProgress();
    });
    row.addEventListener('input', saveProgress);
    if (itinList) itinList.appendChild(row);
  }

  function renumberRows() {
    if (!itinList) return;
    itinList.querySelectorAll('.ets-sf-dyn-row').forEach(function(row,i) {
      var n = row.querySelector('.ets-sf-dyn-num'); if(n) n.textContent = i+1;
    });
  }

  var addItinBtn = document.getElementById('ets-sf-add-itin');
  if (addItinBtn) addItinBtn.addEventListener('click', function(){ addItinRow(); saveProgress(); });

  /* ═══════════════════════════════════════
     CHARACTER COUNTERS
  ═══════════════════════════════════════*/
  document.querySelectorAll('[data-maxlength]').forEach(function(el) {
    var max = parseInt(el.dataset.maxlength,10);
    var field = el.closest('.ets-sf-field');
    var counter = field && field.querySelector('.ets-sf-charcount');
    if (!counter) return;
    function upd() {
      var len = el.value.length;
      counter.textContent = len+' / '+max;
      counter.className = 'ets-sf-charcount'+(len>max*.9?' warn':'')+(len>max?' over':'');
    }
    el.addEventListener('input', upd); upd();
  });

  /* ═══════════════════════════════════════
     LOCALSTORAGE PERSISTENCE
  ═══════════════════════════════════════*/
  function collectSimpleFields() {
    var ids = ['ets-sf-title','ets-sf-description','ets-sf-product-cat','ets-sf-tour-type',
               'ets-sf-badge','ets-sf-duration','ets-sf-group-size','ets-sf-start-point',
               'ets-sf-end-point','ets-sf-whatsapp','ets-sf-price','ets-sf-sale-price',
               'ets-sf-highlights','ets-sf-includes','ets-sf-excludes','ets-sf-know-before',
               'ets-sf-cancellation'];
    var out = {};
    ids.forEach(function(id) {
      var el = document.getElementById(id); if(el) out[id] = el.value;
    });
    out['price_type'] = (document.querySelector('input[name="ets_price_type"]:checked')||{}).value||'per_person';
    out['free_cancel']     = !!(document.getElementById('ets-sf-free-cancel')    && document.getElementById('ets-sf-free-cancel').checked);
    out['instant_confirm'] = !!(document.getElementById('ets-sf-instant-confirm') && document.getElementById('ets-sf-instant-confirm').checked);
    return out;
  }

  function collectItinerary() {
    var rows = [];
    if (itinList) itinList.querySelectorAll('.ets-sf-dyn-row').forEach(function(row) {
      rows.push({
        label:         (row.querySelector('.ets-itin-label')?.value||'').trim(),
        title:         (row.querySelector('.ets-itin-title')?.value||'').trim(),
        description:   (row.querySelector('.ets-itin-desc')?.value||'').trim(),
        accommodation: (row.querySelector('.ets-itin-accommodation')?.value||'').trim(),
        meals:         (row.querySelector('.ets-itin-meals')?.value||'').trim()
      });
    });
    return rows;
  }

  function saveProgress() {
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify({
        step : currentStep,
        fields: collectSimpleFields(),
        ms   : msState,
        itins: collectItinerary()
      }));
    } catch(e) {}
  }

  function restoreProgress() {
    try {
      var raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return;
      var save = JSON.parse(raw);
      if (!save || !save.fields) return;

      /* restore simple fields */
      var f = save.fields;
      ['ets-sf-title','ets-sf-description','ets-sf-product-cat','ets-sf-tour-type',
       'ets-sf-badge','ets-sf-duration','ets-sf-group-size','ets-sf-start-point',
       'ets-sf-end-point','ets-sf-whatsapp','ets-sf-price','ets-sf-sale-price',
       'ets-sf-highlights','ets-sf-includes','ets-sf-excludes','ets-sf-know-before',
       'ets-sf-cancellation'].forEach(function(id) {
        var el = document.getElementById(id);
        if (el && f[id] !== undefined) el.value = f[id];
      });

      /* price type radio */
      if (f.price_type) {
        var r = document.querySelector('input[name="ets_price_type"][value="'+f.price_type+'"]');
        if (r) { r.checked = true; syncPriceVisibility(); }
      }

      /* checkboxes */
      var fc = document.getElementById('ets-sf-free-cancel');
      var ic = document.getElementById('ets-sf-instant-confirm');
      if (fc && f.free_cancel)     fc.checked = true;
      if (ic && f.instant_confirm) ic.checked = true;

      /* multi-select state */
      if (save.ms) {
        ['transport','tour_location','languages'].forEach(function(k) {
          if (save.ms[k]) msState[k] = save.ms[k];
        });
        /* re-render tags for each field */
        ['transport','tour_location','languages'].forEach(function(target) {
          var selId = target === 'tour_location' ? 'ets-sf-location-select'
                    : target === 'languages'     ? 'ets-sf-languages-select'
                    :                              'ets-sf-transport-select';
          var sel = document.getElementById(selId);
          renderTags(target, sel);
        });
      }

      /* itinerary */
      if (save.itins && save.itins.length) {
        save.itins.forEach(function(row){ addItinRow(row); });
      }

      /* re-fire char counters */
      document.querySelectorAll('[data-maxlength]').forEach(function(el){
        el.dispatchEvent(new Event('input'));
      });

      /* restore step (skip validation on restore) */
      if (save.step && save.step > 0) {
        for (var i = 0; i < save.step && i < tabs.length; i++) tabs[i].classList.add('is-done');
        // Directly jump without calling validateStep
        panels[currentStep].classList.remove('is-active');
        tabs[currentStep].classList.remove('is-active');
        currentStep = save.step;
        panels[currentStep].classList.add('is-active');
        tabs[currentStep].classList.add('is-active');
        tabs[currentStep].classList.remove('is-done');
        updateNavButtons();
        if (currentStep === panels.length - 1) buildReview();
      }
    } catch(e) {}
  }

  function clearSavedDraft() {
    try { localStorage.removeItem(SAVE_KEY); } catch(e) {}
  }

  /* ═══════════════════════════════════════
     REVIEW
  ═══════════════════════════════════════*/
  function buildReview() {
    var grid = document.getElementById('ets-sf-review-grid');
    if (!grid) return;
    var sym = (typeof ets_submit_vars !== 'undefined') ? ets_submit_vars.currency_symbol : '';
    var f   = collectSimpleFields();
    var ptFixed = f.price_type !== 'on_request';
    var priceDisplay = ptFixed ? (f['ets-sf-price'] ? sym + f['ets-sf-price'] : '—') : 'Price on Request';

    function msLabels(target) {
      var selId = target==='tour_location'?'ets-sf-location-select':target==='languages'?'ets-sf-languages-select':'ets-sf-transport-select';
      var sel = document.getElementById(selId);
      var vals = msState[target]||[];
      if (!vals.length) return '—';
      return vals.map(function(v) {
        if (!sel) return v;
        for (var i=0;i<sel.options.length;i++) if (sel.options[i].value===v) return sel.options[i].text;
        return v;
      }).join(', ');
    }

    var catSel  = document.getElementById('ets-sf-product-cat');
    var typeSel = document.getElementById('ets-sf-tour-type');
    var items = [
      ['Tour Title',        f['ets-sf-title']        || '—'],
      ['Category',          catSel  && catSel.value  ? catSel.options[catSel.selectedIndex].text   : '—'],
      ['Tour Type',         typeSel && typeSel.value ? typeSel.options[typeSel.selectedIndex].text : '—'],
      ['Duration',          f['ets-sf-duration']     || '—'],
      ['Group Size',        f['ets-sf-group-size']   || '—'],
      ['Transport',         msLabels('transport')],
      ['Start Point',       f['ets-sf-start-point']  || '—'],
      ['Location(s)',       msLabels('tour_location')],
      ['Languages',         msLabels('languages')],
      ['Price',             priceDisplay],
      ['Free Cancellation', f.free_cancel     ? 'Yes' : 'No'],
      ['Instant Confirm',   f.instant_confirm ? 'Yes' : 'No'],
      ['Itinerary Stops',   collectItinerary().length + ' added'],
      ['Photos',            imageFiles.length + ' uploaded'],
    ];
    grid.innerHTML = items.map(function(item) {
      return '<div class="ets-sf-review-item"><div class="ets-sf-review-label">'+esc(item[0])+'</div>'
           + '<div class="ets-sf-review-val">'+esc(String(item[1]))+'</div></div>';
    }).join('');
  }

  /* ═══════════════════════════════════════
     SUBMIT
  ═══════════════════════════════════════*/
  var submitBtn = document.getElementById('ets-sf-submit-btn');
  if (submitBtn) {
    submitBtn.addEventListener('click', function(e) {
      e.preventDefault();
      var f   = collectSimpleFields();
      var priceTypeEl = document.querySelector('input[name="ets_price_type"]:checked');
      var data = {
        title:             f['ets-sf-title'],
        description:       f['ets-sf-description'],
        product_cat:       f['ets-sf-product-cat'],
        tour_type:         f['ets-sf-tour-type'],
        badge:             f['ets-sf-badge'],
        duration:          f['ets-sf-duration'],
        group_size:        f['ets-sf-group-size'],
        transport:         f['ets-sf-transport'] || (msState.transport||[]).join(','),
        start_point:       f['ets-sf-start-point'],
        end_point:         f['ets-sf-end-point'],
        tour_location:     (msState.tour_location||[]),
        languages:         (msState.languages||[]).join(','),
        whatsapp:          f['ets-sf-whatsapp'],
        price_type:        f.price_type,
        price:             f['ets-sf-price'],
        sale_price:        f['ets-sf-sale-price'],
        highlights:        f['ets-sf-highlights'],
        includes:          f['ets-sf-includes'],
        excludes:          f['ets-sf-excludes'],
        know_before:       f['ets-sf-know-before'],
        cancellation:      f['ets-sf-cancellation'],
        free_cancellation: f.free_cancel,
        instant_confirm:   f.instant_confirm,
        itinerary:         collectItinerary()
      };

      var formData = new FormData();
      formData.append('action',           'ets_submit_tour');
      formData.append('ets_submit_nonce', (document.getElementById('ets_submit_nonce')||{}).value||'');
      formData.append('data',             JSON.stringify(data));
      imageFiles.forEach(function(file){ formData.append('tour_images[]', file, file.name); });

      submitBtn.classList.add('is-loading');
      submitBtn.disabled = true;
      var url = (typeof ets_submit_vars!=='undefined') ? ets_submit_vars.ajax_url : '/wp-admin/admin-ajax.php';

      fetch(url, { method:'POST', body:formData, credentials:'same-origin' })
        .then(function(r){ return r.json(); })
        .then(function(res) {
          submitBtn.classList.remove('is-loading'); submitBtn.disabled = false;
          if (res.success) {
            clearSavedDraft();
            document.getElementById('ets-sf-form-wrap').style.display = 'none';
            var success = document.getElementById('ets-sf-success');
            if (success) success.classList.add('is-active');
            var link = document.getElementById('ets-sf-success-link');
            if (link && res.data && res.data.url) { link.href=res.data.url; link.style.display='inline-flex'; }
          } else {
            showNotice(res.data||'Something went wrong. Please try again.', panels[currentStep]);
          }
        })
        .catch(function() {
          submitBtn.classList.remove('is-loading'); submitBtn.disabled = false;
          showNotice('Network error. Please check your connection.', panels[currentStep]);
        });
    });
  }

  /* ═══════════════════════════════════════
     UTILITY
  ═══════════════════════════════════════*/
  function esc(s) {
    return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }

  /* ═══════════════════════════════════════
     INIT
  ═══════════════════════════════════════*/
  initMultiSelects();
  restoreProgress();
  if (currentStep === 0) goToStep(0);

})();