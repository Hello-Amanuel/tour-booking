/* Ethio Tour System — Admin JS v4.0
   Itinerary builder only.
   Removed: FAQ builder, Distance field from itinerary.
*/
jQuery(function ($) {

    if (typeof ets_admin === 'undefined') {
        window.ets_admin = { itinerary: [] };
    }

    /* ─── Helpers ─── */
    function lbl(text) {
        return $('<label style="display:block;font-size:12px;font-weight:600;margin-bottom:4px;color:#555;">').text(text);
    }
    function col(labelText, input) {
        return $('<div>').append(lbl(labelText)).append(input);
    }

    /* ─── Itinerary Builder ─── */
    var $iRows   = $('#ets-itinerary-rows');
    var existing = ets_admin.itinerary || [];

    function iRow(data) {
        data = data || {};
        return $('<div class="ets-admin-row" style="border:1px solid #ddd;border-radius:6px;padding:16px;margin-bottom:12px;background:#fff;">')
            .append(
                $('<div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">')
                    .append(
                        $('<input type="text" name="ets_day_label[]" placeholder="Day 1 / Stop 1" style="flex:1;font-weight:600;">')
                            .val(data.label || '')
                    )
                    .append(
                        $('<button type="button" class="button button-link-delete ets-remove-row" style="color:#c00;">✕ Remove</button>')
                    )
            )
            .append(lbl('Title'))
            .append(
                $('<input type="text" name="ets_day_title[]" style="width:100%;margin-bottom:8px;">')
                    .val(data.title || '')
            )
            .append(lbl('Description'))
            .append(
                $('<textarea name="ets_day_desc[]" rows="3" style="width:100%;margin-bottom:8px;">')
                    .val(data.description || '')
            )
            .append(
                $('<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">')
                    .append(col('Accommodation',
                        $('<input type="text" name="ets_day_accommodation[]" style="width:100%;">')
                            .val(data.accommodation || '')
                    ))
                    .append(col('Meals Included',
                        $('<input type="text" name="ets_day_meals[]" style="width:100%;">')
                            .val(data.meals || '')
                    ))
            );
    }

    function setIEmpty() {
        if (!$iRows.find('.ets-admin-row').length) {
            $iRows.html('<p class="ets-empty-msg" style="color:#999;font-style:italic;margin:10px 0;">No itinerary added yet.</p>');
        }
    }

    // Load existing data
    if (existing.length) {
        existing.forEach(function (item) { $iRows.append(iRow(item)); });
    } else {
        setIEmpty();
    }

    $('#ets-add-day').on('click', function () {
        $iRows.find('.ets-empty-msg').remove();
        $iRows.append(iRow());
    });

    $iRows.on('click', '.ets-remove-row', function () {
        $(this).closest('.ets-admin-row').remove();
        setIEmpty();
    });

    // Serialize on save
    $('#post').on('submit', function () {
        var rows = [];
        $iRows.find('.ets-admin-row').each(function () {
            rows.push({
                label:         $(this).find('[name="ets_day_label[]"]').val(),
                title:         $(this).find('[name="ets_day_title[]"]').val(),
                description:   $(this).find('[name="ets_day_desc[]"]').val(),
                accommodation: $(this).find('[name="ets_day_accommodation[]"]').val(),
                meals:         $(this).find('[name="ets_day_meals[]"]').val(),
            });
        });
        $('#ets-itinerary-json').val(JSON.stringify(rows));
    });

});
